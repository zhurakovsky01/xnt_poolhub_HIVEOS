#!/bin/bash

# Pfade
LOGFILE="/var/log/miner/custom/custom.log"
> "$LOGFILE" # Log vor dem Start leeren
MINER_DIR=$(dirname "$(readlink -f "$0")")
CONFIG_FILE="$MINER_DIR/oxzd_config.json"
OXZD_CONF="$MINER_DIR/oxzd.conf"

# Prüfe, ob oxzd.conf existiert
if [[ ! -f "$OXZD_CONF" ]]; then
    echo "[OXZD] ERROR: oxzd.conf nicht gefunden!"
    exit 1
fi

# Prüfe, ob die Konfiguration ein gültiges JSON-Format hat
jq . "$OXZD_CONF" >/dev/null 2>&1
if [[ $? -ne 0 ]]; then
    echo "[OXZD] ERROR: Konfigurationsdatei $OXZD_CONF ist kein gültiges JSON!"
    echo "[OXZD] Inhalt der oxzd.conf:"
    cat "$OXZD_CONF"
    exit 1
fi

# ------------------------------------------------------------------
# FIX: Liest jetzt auch "idle-command" (mit Bindestrich) aus HiveOS
# ------------------------------------------------------------------
GPU_IDLE_COMMAND=$(jq -r '."idle-command" // .gpu_idle_command // ""' "$OXZD_CONF")
CPU_IDLE_COMMAND=$(jq -r '."cpu-idle-command" // .cpu_idle_command // ""' "$OXZD_CONF")

MAIN_ALGO_GPU=$(jq -r '.main_algo_gpu // ""' "$OXZD_CONF")
MAIN_ALGO_CPU=$(jq -r '.main_algo_cpu // ""' "$OXZD_CONF")

# Adressen lesen
NPT_ADDRESS=$(jq -r '.npt_address // ""' "$OXZD_CONF")
XELIS_ADDRESS=$(jq -r '.xelis_address // ""' "$OXZD_CONF")
TARI_ADDRESS=$(jq -r '.tari_address // ""' "$OXZD_CONF")
XNT_ADDRESS=$(jq -r '.xnt_address // ""' "$OXZD_CONF")

# Pools lesen
POOL_NEPTUNE=$(jq -r '.npt_url // "stratum+ssl://eu.poolhub.io:4444"' "$OXZD_CONF")
POOL_XELIS=$(jq -r '.xelis_url // "stratum+tcp://xelis.mine.zergpool.com:4444"' "$OXZD_CONF")
POOL_TARI=$(jq -r '.tari_url // "stratum+tcp://de-eu.luckypool.io:6118"' "$OXZD_CONF")
POOL_XNT=$(jq -r '.xnt_url // "stratum+ssl://eu.poolhub.io:30111"' "$OXZD_CONF")

# Worker Name
WORKER_NAME=$(jq -r '.worker_name // ""' "$OXZD_CONF")
if [[ -z "$WORKER_NAME" ]]; then
    WORKER_NAME=$(hostname)
fi

# Prüfe, ob mindestens ein Algorithmus ausgewählt ist
if [[ -z "$MAIN_ALGO_GPU" && -z "$MAIN_ALGO_CPU" ]]; then
    echo "[OXZD] ERROR: Mindestens ein Algorithmus (main_algo_gpu oder main_algo_cpu) muss ausgewählt sein!"
    exit 1
fi

# Prüfe, ob Adressen gesetzt sind
if [[ -z "$NPT_ADDRESS" && ( "$MAIN_ALGO_CPU" == "neptune" || "$MAIN_ALGO_GPU" == "neptune" ) ]]; then
    echo "[OXZD] ERROR: npt_address muss gesetzt sein für Neptune!"
    exit 1
fi
if [[ -z "$XELIS_ADDRESS" && "$MAIN_ALGO_CPU" == "xelis" ]]; then
    echo "[OXZD] ERROR: xelis_address muss gesetzt sein für Xelis-CPU!"
    exit 1
fi
if [[ "$GPU_IDLE_COMMAND" == "tari" && -z "$TARI_ADDRESS" ]]; then
    echo "[OXZD] ERROR: tari_address muss gesetzt sein für Tari-GPU!"
    exit 1
fi
if [[ -z "$XNT_ADDRESS" && "$MAIN_ALGO_GPU" == "xnt" ]]; then
    echo "[OXZD] ERROR: xnt_address muss gesetzt sein für Nexaint (XNT)!"
    exit 1
fi

# Ermittle die Anzahl der verfügbaren CPU-Threads
AVAILABLE_THREADS=$(nproc)
if [[ "$AVAILABLE_THREADS" -lt 1 ]]; then
    AVAILABLE_THREADS=1
fi

# Funktion zum Erstellen der oxzd_config.json
create_config() {
    local selected_algo="$1"
    local algo_list=()

    # Bestimme den Idle-Algorithmus
    local idle_algo_id=""
    
    # Add main algorithm first
    case "$selected_algo" in
        "neptune-gpu")
            algo_list+=("{\"id\": \"neptune-gpu\", \"algo\": \"neptune\", \"pool\": \"$POOL_NEPTUNE\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$NPT_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"gpu\", \"option\": \"all\"}}")
            ;;
        "neptune-cpu")
            algo_list+=("{\"id\": \"neptune-cpu\", \"algo\": \"neptune\", \"pool\": \"$POOL_NEPTUNE\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$NPT_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"cpu\", \"threads\": $AVAILABLE_THREADS}}")
            ;;
        "xelis-cpu")
            algo_list+=("{\"id\": \"xelis-cpu\", \"algo\": \"xelis_v2\", \"pool\": \"$POOL_XELIS\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$XELIS_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"cpu\", \"threads\": $AVAILABLE_THREADS}}")
            ;;
        "xnt-gpu") 
            algo_list+=("{\"id\": \"xnt-gpu\", \"algo\": \"xnt\", \"pool\": \"$POOL_XNT\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$XNT_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"gpu\", \"option\": \"all\"}}")
            ;;
    esac

    # Add idle algorithm after main algorithm
    if [[ "$GPU_IDLE_COMMAND" == "qubic" || "$GPU_IDLE_COMMAND" == "qubic_solo" ]]; then
        # HINWEIS: Stelle sicher, dass download_qubic_miner etc. irgendwo definiert sind, falls du Qubic nutzt!
        download_qubic_miner
        local pps_value="true"
        if [[ "$GPU_IDLE_COMMAND" == "qubic_solo" ]]; then
            pps_value="false"
        fi
        create_qubic_appsettings "gpu" "$pps_value" "$QUBIC_ADDRESS"
        create_qubic_wrapper
        idle_algo_id="qubic-gpu"
        algo_list+=("{\"id\": \"qubic-gpu\", \"command\": \"$QLI_WRAPPER\"}")
    elif [[ "$GPU_IDLE_COMMAND" == "tari" ]]; then
        idle_algo_id="tari-gpu"
        algo_list+=("{\"id\": \"tari-gpu\", \"algo\": \"tari_sha3x\", \"pool\": \"$POOL_TARI\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$TARI_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"gpu\", \"option\": \"all\"}}")
    elif [[ -n "$GPU_IDLE_COMMAND" ]]; then
        # HIER wird dein lolminer command verarbeitet
        idle_algo_id="my-idle-command"
        # Wir escapen Anführungszeichen innerhalb des Commands sicherheitshalber
        CLEAN_IDLE_COMMAND=$(echo "$GPU_IDLE_COMMAND" | sed 's/"/\\"/g')
        algo_list+=("{\"id\": \"my-idle-command\", \"command\": \"$CLEAN_IDLE_COMMAND\"}")
    fi
    
    if [[ "$CPU_IDLE_COMMAND" == "qubic" || "$CPU_IDLE_COMMAND" == "qubic_solo" ]]; then
        download_qubic_miner
        local pps_value="true"
        if [[ "$CPU_IDLE_COMMAND" == "qubic_solo" ]]; then
            pps_value="false"
        fi
        create_qubic_appsettings "cpu" "$pps_value" "$QUBIC_ADDRESS"
        create_qubic_wrapper
        idle_algo_id="qubic-cpu"
        algo_list+=("{\"id\": \"qubic-cpu\", \"command\": \"$QLI_WRAPPER\"}")
    fi

    # Update idle_algos in the main algorithm entry ONLY if idle_algo_id is set
    if [[ -n "$idle_algo_id" ]]; then
        for i in "${!algo_list[@]}"; do
            # Nur dem Haupt-Algo das idle_algos Feld hinzufügen
            if [[ "${algo_list[$i]}" == *"$selected_algo"* ]]; then
                 algo_list[$i]=$(echo "${algo_list[$i]}" | jq --arg idle_algo_id "$idle_algo_id" '.idle_algos = [$idle_algo_id]')
            fi
        done
    fi

    SELECTED_JSON=$(printf '%s\n' "$selected_algo" | jq -R . | jq -s .)
    ALGO_LIST_JSON=$(printf '%s\n' "${algo_list[@]}" | jq -s .)

    if [[ -z "$SELECTED_JSON" || "$SELECTED_JSON" == "[]" ]]; then
        echo "[OXZD] ERROR: Keine Algorithmen ausgewählt!"
        exit 1
    fi

    jq -n --argjson selected "$SELECTED_JSON" --argjson algo_list "$ALGO_LIST_JSON" \
      '{"selected": $selected, "algo_list": $algo_list}' > "$CONFIG_FILE"

    if [[ ! -s "$CONFIG_FILE" ]]; then
        echo "[OXZD] ERROR: oxzd_config.json konnte nicht erstellt werden!"
        cat "$CONFIG_FILE"
        exit 1
    fi
    echo "[OXZD] Config file $CONFIG_FILE generated successfully."
}

# Bestimme den Hauptalgorithmus
SELECTED_ALGO=""
if [[ -n "$MAIN_ALGO_CPU" ]]; then
    if [[ "$MAIN_ALGO_CPU" == "neptune" ]]; then
        SELECTED_ALGO="neptune-cpu"
    elif [[ "$MAIN_ALGO_CPU" == "xelis" ]]; then
        SELECTED_ALGO="xelis-cpu"
    fi
elif [[ -n "$MAIN_ALGO_GPU" ]]; then
    if [[ "$MAIN_ALGO_GPU" == "neptune" ]]; then
        SELECTED_ALGO="neptune-gpu"
    elif [[ "$MAIN_ALGO_GPU" == "xnt" ]]; then
        SELECTED_ALGO="xnt-gpu"
    fi
fi

if [[ -z "$SELECTED_ALGO" ]]; then
    echo "[OXZD] ERROR: Kein gültiger Algorithmus ausgewählt! MAIN_ALGO_GPU=$MAIN_ALGO_GPU, MAIN_ALGO_CPU=$MAIN_ALGO_CPU"
    exit 1
fi

# Erstelle die anfängliche Konfiguration
create_config "$SELECTED_ALGO"

# Debug: Print generated config
echo "[OXZD] Generated oxzd_config.json:"
cat "$CONFIG_FILE"

# Starte Miner
cd "$MINER_DIR" || { echo "[OXZD] ERROR: Kann Verzeichnis $MINER_DIR nicht öffnen"; exit 1; }
chmod +x oxzd

echo "[OXZD] Starte Miner mit Algorithmus: $SELECTED_ALGO"
case "$SELECTED_ALGO" in
    "neptune-gpu")
        ./oxzd run --algos neptune-gpu 2>&1 | tee -a "$LOGFILE"
        ;;
    "neptune-cpu")
        ./oxzd run --algos neptune-cpu 2>&1 | tee -a "$LOGFILE"
        ;;
    "xelis-cpu")
        ./oxzd run --algos xelis-cpu 2>&1 | tee -a "$LOGFILE"
        ;;
    "xnt-gpu")
        ./oxzd run --algos xnt-gpu 2>&1 | tee -a "$LOGFILE"
        ;;
    *)
        echo "[OXZD] WARN: Unbekannter Algorithmus: $SELECTED_ALGO"
        exit 1
        ;;
esac