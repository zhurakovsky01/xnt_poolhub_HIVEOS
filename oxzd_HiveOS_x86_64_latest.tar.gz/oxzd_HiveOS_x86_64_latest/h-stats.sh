#!/bin/bash

LOGFILE="/var/log/miner/custom/custom.log"

# Alle Zeilen finden, die mit "GPU" beginnen
gpu_lines=$(grep -oP 'GPU[0-9]+.*' "$LOGFILE" | tail -n 50)

temps=()
fans=()
powers=()
loads=()
busids=()
brands=()
mtemps=()
jtemps=()

while read -r line; do
    # GPU ID extrahieren (nur Zahl)
    id=$(echo "$line" | grep -oP 'GPU\K[0-9]+')

    # Temp
    temp=$(echo "$line" | awk -F'|' '{print $5}' | awk '{print $1}')
    temps+=("$temp")

    # Fan (nicht vorhanden)
    fans+=("0")

    # Power (Prozent entfernen)
    power=$(echo "$line" | awk -F'|' '{print $4}' | awk '{print $1}' | sed 's/%//')
    powers+=("$power")

    # Load
    loads+=("100")

    # Bus-ID korrekt generieren (00, 01, 02 ...)
    bus=$(printf "%02X:00.0" "$id")
    busids+=("$bus")

    # Brand
    brands+=("nvidia")

    # Fake memory/junction temp
    mtemps+=("$temp")
    jtemps+=("$temp")

done <<< "$gpu_lines"

# Array builder
function join_array() {
    local arr=("$@")
    local out=""
    for v in "${arr[@]}"; do
        out+="\"$v\","
    done
    echo "[${out%,}]"
}

# JSON Ausgabe
cat <<EOF
{
  "temp": $(join_array "${temps[@]}"),
  "fan": $(join_array "${fans[@]}"),
  "power": $(join_array "${powers[@]}"),
  "busids": $(join_array "${busids[@]}"),
  "brand": $(join_array "${brands[@]}"),
  "load": $(join_array "${loads[@]}"),
  "mtemp": $(join_array "${mtemps[@]}"),
  "jtemp": $(join_array "${jtemps[@]}")
}
EOF
