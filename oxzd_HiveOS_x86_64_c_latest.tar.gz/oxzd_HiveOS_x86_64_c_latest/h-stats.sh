#!/bin/bash

# Pfade
logfile="/var/log/miner/custom/custom.log"
conf_file="/hive/miners/custom/oxzd_HiveOS_x86_64_latest/h-config.sh"
oxzd_conf="/hive/miners/custom/oxzd_HiveOS_x86_64_latest/oxzd.conf"

# --- Globale Variablen initialisieren ---
total_khs=0
gpu_count=0
algo="unknown"
hs_units="khs"
accepted_shares=0
rejected_shares=0
ver="0.7.4"

# Arrays initialisieren
declare -a hs temp fan bus_numbers

# Log einlesen (letzte 100 Zeilen)
miner_log=$(tail -n 100 "$logfile" 2>/dev/null || echo "")

# Konfiguration lesen
main_algo_gpu=$(jq -r '.main_algo_gpu // ""' "$oxzd_conf" 2>/dev/null || echo "")
main_algo_cpu=$(jq -r '.main_algo_cpu // ""' "$oxzd_conf" 2>/dev/null || echo "")
gpu_idle_command=$(jq -r '.gpu_idle_command // ""' "$oxzd_conf" 2>/dev/null || echo "")

# GPU Anzahl ermitteln
gpu_count=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l)
if [[ -z "$gpu_count" || "$gpu_count" -eq 0 ]]; then
  gpu_count=1 
fi

# Arrays mit 0 vorbefüllen
for ((i=0; i<gpu_count; i++)); do
  hs[$i]=0
  temp[$i]=0
  fan[$i]=0
  bus_numbers[$i]=0
done

# --- Hardware Stats holen (Temp, Fan, BusID) ---
gpu_stats_raw=$(nvidia-smi --query-gpu=temperature.gpu,fan.speed,pci.bus_id --format=csv,noheader,nounits 2>/dev/null | sed 's/ //g')

i=0
while IFS=',' read -r t f b; do
  if [[ $i -ge $gpu_count ]]; then break; fi
  # Bus ID hex zu dezimal wandeln
  bus_hex=$(echo "$b" | cut -d':' -f2 | cut -d'.' -f1 2>/dev/null || echo "00")
  bus_dec=$((16#${bus_hex}))
  temp[$i]=$t
  fan[$i]=$f
  bus_numbers[$i]=$bus_dec
  ((i++))
done <<< "$gpu_stats_raw"


# --- Hashrate Parser Funktionen ---

extract_xnt_gpu() {
  # 1. Total Hashrate suchen
  total_line=$(echo "$miner_log" | grep -E "Total \| xnt:" | tail -n1)
  if [[ $total_line =~ xnt:[[:space:]]*([0-9.]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "$total_mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
  fi

  # 2. Per GPU Hashrate suchen
  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep "GPU$i" | grep "xnt" | grep "MH/s" | tail -n1)
    if [[ $line =~ ([0-9]+\.[0-9]+)[[:space:]]*MH/s ]]; then
       val_mhs="${BASH_REMATCH[1]}"
       hs[$i]=$(echo "$val_mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
    else
       hs[$i]=0
    fi
  done
  
  if [[ -z "$total_khs" || "$total_khs" -eq 0 ]]; then
     sum=0
     for val in "${hs[@]}"; do sum=$((sum + val)); done
     total_khs=$sum
  fi
  algo="XNT"
  hs_units="khs"
}

extract_tip5_gpu() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tip5:[[:space:]]*[0-9.]+" | tail -n1)
  if [[ $total_line =~ tip5:[[:space:]]*([0-9.]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "$total_mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
  fi
  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep "GPU$i" | grep "MH/s" | tail -n1)
    if [[ $line =~ ([0-9]+\.[0-9]+)[[:space:]]*MH/s ]]; then
      mhs="${BASH_REMATCH[1]}"
      hs[$i]=$(echo "$mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
    fi
  done
  algo="TIP5"
  hs_units="mhs"
}

extract_neptune_cpu() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tip5:[[:space:]]*[0-9.]+" | tail -n1)
  if [[ $total_line =~ tip5:[[:space:]]*([0-9.]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "$total_mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
    hs[0]=$total_khs
  fi
  algo="TIP5"
  hs_units="mhs"
}

extract_tari_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tari-sha3x:" | tail -n1)
  if [[ $total_line =~ ([0-9]+\.[0-9]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "$total_mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
  fi
  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep "GPU$i" | grep "MH/s" | tail -n1)
    if [[ $line =~ ([0-9]+\.[0-9]+)[[:space:]]*MH/s ]]; then
      mhs="${BASH_REMATCH[1]}"
      hs[$i]=$(echo "$mhs * 1000" | bc 2>/dev/null | awk '{printf "%.0f", $0}')
    fi
  done
  algo="TARI"
  hs_units="mhs"
}

extract_xelishashv2_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total: [0-9.]+ KH/s" | tail -n1)
  if [[ $total_line =~ Total:[[:space:]]*([0-9.]+) ]]; then
    total_khs="${BASH_REMATCH[1]}"
  fi
  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep -m1 "\|$i\|")
    if [[ $line =~ \|$i\|[^|]+\|([0-9.]+) ]]; then
      hs[$i]="${BASH_REMATCH[1]}"
    fi
  done
  algo="XEL"
  hs_units="hs"
}

extract_cpu_xelis_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total \| xelis-v2:" | tail -n1)
  if [[ $total_line =~ ([0-9.]+)[[:space:]]kH/s ]]; then
    total_khs="${BASH_REMATCH[1]}"
    hs[0]="$total_khs"
  fi
  algo="XEL"
  hs_units="hs"
}

# --- Algo Erkennung ---

selected="unknown"
if [[ "$main_algo_gpu" == "xnt" ]]; then
  selected="xnt-gpu"
elif [[ "$main_algo_gpu" == "tip5" ]]; then
  selected="gpu-tip5"
elif [[ "$main_algo_cpu" == "neptune" ]]; then
  selected="neptune-cpu"
elif [[ -n "$main_algo_cpu" ]]; then
  selected="cpu-xelis"
fi

# Fallback auf Log
if [[ "$selected" == "unknown" ]]; then
  if echo "$miner_log" | grep -q "xnt:"; then
    selected="xnt-gpu"
  elif echo "$miner_log" | grep -q "tip5"; then
    if echo "$miner_log" | grep -q "GPU[0-9]"; then
      selected="gpu-tip5"
    else
      selected="neptune-cpu"
    fi
  fi
fi

# Idle checks (ohne Qubic)
if [[ "$selected" == "gpu-tip5" || "$selected" == "xnt-gpu" ]]; then
  if [[ "$gpu_idle_command" == *"xelishashv2"* ]] && echo "$miner_log" | grep -q "xelishashv2"; then
    selected="xelishashv2"
  elif [[ "$gpu_idle_command" == *"tari"* ]] && echo "$miner_log" | grep -q "tari-sha3x"; then
    selected="tari"
  fi
fi

# CPU Temp Fix für CPU Algos
if [[ "$selected" == "neptune-cpu" || "$selected" == "cpu-xelis" ]]; then
   temp[0]=$(cpu-temp 2>/dev/null || echo 0)
   fan[0]=0
   bus_numbers[0]=0
fi

# --- Aufruf der Parser ---
case "$selected" in
  "xnt-gpu") extract_xnt_gpu ;;
  "gpu-tip5") extract_tip5_gpu ;;
  "neptune-cpu") extract_neptune_cpu ;;
  "tari") extract_tari_stats ;;
  "xelishashv2") extract_xelishashv2_stats ;;
  "cpu-xelis") extract_cpu_xelis_stats ;;
  *) total_khs=0 ;;
esac

# Version holen
ver_log=$(echo "$miner_log" | grep -o "OXZD [0-9.]*" | tail -n1 | grep -o "[0-9.]*" )
if [[ -n "$ver_log" ]]; then ver="OXZD $ver_log"; fi

# Uptime
uptime=0
if [[ -f "$logfile" && -f "$conf_file" ]]; then
  log_time=$(stat -c %Y "$logfile" 2>/dev/null || echo 0)
  conf_time=$(stat -c %Y "$conf_file" 2>/dev/null || echo 0)
  ((uptime = log_time - conf_time))
  if [[ $uptime -lt 0 ]]; then uptime=0; fi
fi

# --- JSON Manuell bauen (Fix für jq Fehler) ---
build_json_array() {
  local -n arr=$1
  local json_str="["
  for ((i=0; i<gpu_count; i++)); do
    val=${arr[$i]}
    if [[ -z "$val" ]]; then val=0; fi
    json_str+="$val"
    if [[ $i -lt $((gpu_count-1)) ]]; then json_str+=","; fi
  done
  json_str+="]"
  echo "$json_str"
}

hs_json=$(build_json_array hs)
temp_json=$(build_json_array temp)
fan_json=$(build_json_array fan)
bus_json=$(build_json_array bus_numbers)

stats=$(jq -nc \
  --argjson total_khs "$total_khs" \
  --argjson hs "$hs_json" \
  --arg hs_units "$hs_units" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --argjson bus_numbers "$bus_json" \
  --arg uptime "$uptime" \
  --arg ver "$ver" \
  --arg algo "$algo" \
  '{total_khs:$total_khs, hs:$hs, hs_units:$hs_units, temp:$temp, fan:$fan, bus_numbers:$bus_numbers, uptime:$uptime, ver:$ver, ar:[0,0], algo:$algo}')

echo "$total_khs"
echo "$stats"