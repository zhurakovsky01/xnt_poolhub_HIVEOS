#!/bin/bash

# Zielpfad für oxzd.conf
CONF_PATH="/hive/miners/custom/oxzd_HiveOS_znver4_latest/oxzd.conf"
CONF_DIR=$(dirname "$CONF_PATH")

# Debug-Ausgabe
echo "DEBUG: Starting h-config.sh..." >&2
echo "DEBUG: CUSTOM_USER_CONFIG=$CUSTOM_USER_CONFIG" >&2

# Stelle sicher, dass das Zielverzeichnis existiert
if [ ! -d "$CONF_DIR" ]; then
    echo "DEBUG: Directory $CONF_DIR does not exist. Creating it..." >&2
    mkdir -p "$CONF_DIR"
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to create directory $CONF_DIR" >&2
        exit 1
    fi
fi

# Prüfen, ob CUSTOM_USER_CONFIG gesetzt ist
if [ -n "$CUSTOM_USER_CONFIG" ]; then
    echo "DEBUG: Writing CUSTOM_USER_CONFIG to $CONF_PATH" >&2
    echo -e "$CUSTOM_USER_CONFIG" > "$CONF_PATH"
    
    if [ -f "$CONF_PATH" ]; then
        echo "DEBUG: Successfully created $CONF_PATH:" >&2
        cat "$CONF_PATH" >&2
    else
        echo "ERROR: Failed to write config file at $CONF_PATH" >&2
        exit 1
    fi
else
    echo "ERROR: CUSTOM_USER_CONFIG is empty!" >&2
    exit 1
fi

echo "Config file oxzd.conf generated successfully."
